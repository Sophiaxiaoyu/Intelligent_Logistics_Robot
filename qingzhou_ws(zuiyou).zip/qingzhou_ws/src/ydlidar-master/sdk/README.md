YDLIDAR SDK PACKAGE V1.3.2
=====================================================================

SDK test application for YDLIDAR

Visit EAI Website for more details about YDLIDAR.

How to build YDLIDAR SDK samples
=====================================================================
    1) Clone this project to your computer folder
    2) Clone this project to your computer folder
    2) Running cmake to build ydlidar_test
    
How to run YDLIDAR SDK samples
=====================================================================
    --$ cd samples
    --$ ./ydlidar_test /dev/ttyUSB0 115200 0

You should see YDLIDAR's scan result in the console


Upgrade Log
=====================================================================

2018-04-16 version:1.3.2

   1.add multithreading support.

2018-04-16 version:1.3.1

   1.Compensate for each laser point timestamp.

