var searchData=
[
  ['enableconstfreq',['enableConstFreq',['../classydlidar_1_1_y_dlidar_driver.html#a1e5c25618be9867dfdb1aa2f5e9cb93c',1,'ydlidar::YDlidarDriver']]],
  ['enablelowerpower',['enableLowerPower',['../classydlidar_1_1_y_dlidar_driver.html#a85a9af2aff7201a42f000299990b0ce5',1,'ydlidar::YDlidarDriver']]]
];
