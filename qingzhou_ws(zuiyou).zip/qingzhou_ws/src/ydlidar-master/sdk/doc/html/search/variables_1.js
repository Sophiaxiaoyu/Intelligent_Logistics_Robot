var searchData=
[
  ['ang_5fincrement',['ang_increment',['../struct_laser_config.html#a67279ae0f648a129521576f52c321932',1,'LaserConfig']]]
];
