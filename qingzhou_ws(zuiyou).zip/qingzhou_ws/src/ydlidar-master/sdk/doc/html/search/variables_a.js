var searchData=
[
  ['range_5fres',['range_res',['../struct_laser_config.html#ae52eb0e0aca41f6dde58700a642e4c80',1,'LaserConfig']]],
  ['ranges',['ranges',['../struct_laser_scan.html#a4d059cb77f0f9f6e558db50c9993f7df',1,'LaserScan']]],
  ['rate',['rate',['../structsampling__rate.html#a8d860fbedd930d2022fe7bb6cf1f78b6',1,'sampling_rate']]],
  ['read_5ftimeout_5fconstant',['read_timeout_constant',['../structserial_1_1_timeout.html#a099244649dec66b6e0548480edeb2b9f',1,'serial::Timeout']]],
  ['read_5ftimeout_5fmultiplier',['read_timeout_multiplier',['../structserial_1_1_timeout.html#a64412753eb2edf1621716dd9f1a4e71e',1,'serial::Timeout']]]
];
