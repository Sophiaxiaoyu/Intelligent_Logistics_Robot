var searchData=
[
  ['scan_5fnode_5fbuf',['scan_node_buf',['../classydlidar_1_1_y_dlidar_driver.html#aeaefa47c69cbb0439b1259bdc6ccb29e',1,'ydlidar::YDlidarDriver']]],
  ['scan_5fnode_5fcount',['scan_node_count',['../classydlidar_1_1_y_dlidar_driver.html#a106fc563bb42f19e84e8d9db1e7856fe',1,'ydlidar::YDlidarDriver']]],
  ['scan_5ftime',['scan_time',['../struct_laser_config.html#af40c5e3902bb931e337ea400682e5636',1,'LaserConfig']]],
  ['self_5ftime_5fstamp',['self_time_stamp',['../struct_laser_scan.html#ad37e2a54c7eff58cad7576d51916b859',1,'LaserScan']]],
  ['serialnum',['serialnum',['../structdevice__info.html#abf23e35480aff36d846085ca6fd0eec3',1,'device_info']]],
  ['status',['status',['../structdevice__health.html#ac3425f5555ecbb5a0da03b4cabe2777c',1,'device_health']]],
  ['system_5ftime_5fstamp',['system_time_stamp',['../struct_laser_scan.html#a1bb6b997ce698fbc516bc20ab3ba3399',1,'LaserScan']]]
];
